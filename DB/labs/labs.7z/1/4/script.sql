create database DB_Lab04;
use DB_Lab04;
select DB_NAME();

